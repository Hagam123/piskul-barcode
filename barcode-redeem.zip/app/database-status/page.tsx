"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Database, CheckCircle, XCircle, RefreshCw, AlertCircle, Shield } from "lucide-react"
import Link from "next/link"
import { checkDatabaseSetup } from "@/lib/supabase"

export default function DatabaseStatusPage() {
  const [isConnected, setIsConnected] = useState<boolean | null>(null)
  const [barcodeCount, setBarcodeCount] = useState<number | null>(null)
  const [scanCount, setScanCount] = useState<number | null>(null)
  const [giftCount, setGiftCount] = useState<number | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [supabaseUrl, setSupabaseUrl] = useState<string | null>(null)

  const checkDatabaseStatus = async () => {
    setLoading(true)
    setError(null)

    try {
      // Cek URL Supabase
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      setSupabaseUrl(url || "Not configured")

      // Test koneksi database dan setup
      const setupResult = await checkDatabaseSetup()

      if (setupResult.error) {
        setError(setupResult.error)
        setIsConnected(false)
      } else {
        setIsConnected(setupResult.tablesExist)
        setBarcodeCount(setupResult.barcodesCount)
        setScanCount(setupResult.scansCount)
        setGiftCount(setupResult.giftCount)
      }
    } catch (e) {
      console.error("Error checking database status:", e)
      setError(e instanceof Error ? e.message : "Unknown error occurred")
      setIsConnected(false)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    checkDatabaseStatus()
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Kembali ke Scanner
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                  <Database className="w-6 h-6 text-blue-600" />
                  Status Database
                </h1>
                <p className="text-gray-600">Cek koneksi dan status database Supabase</p>
              </div>
            </div>
            <Button onClick={checkDatabaseStatus} disabled={loading} className="flex items-center gap-2">
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
              {loading ? "Memeriksa..." : "Refresh"}
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Connection Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Status Koneksi Database
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {loading ? (
              <div className="flex items-center justify-center p-6">
                <div className="flex flex-col items-center gap-3">
                  <RefreshCw className="w-8 h-8 text-blue-600 animate-spin" />
                  <p className="text-gray-600">Memeriksa koneksi database...</p>
                </div>
              </div>
            ) : error ? (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <AlertCircle className="w-6 h-6 text-red-600" />
                  <div>
                    <h3 className="font-bold text-red-700">Error Koneksi Database</h3>
                    <p className="text-sm text-red-600">{error}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center ${isConnected ? "bg-green-500" : "bg-red-500"}`}
                    >
                      {isConnected ? (
                        <CheckCircle className="w-6 h-6 text-white" />
                      ) : (
                        <XCircle className="w-6 h-6 text-white" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900">Status Koneksi</h3>
                      <p className="text-sm text-gray-600">
                        {isConnected ? "Terhubung ke database Supabase" : "Tidak dapat terhubung ke database Supabase"}
                      </p>
                    </div>
                  </div>
                  <Badge className={isConnected ? "bg-green-500 text-white" : "bg-red-500 text-white"}>
                    {isConnected ? "Connected" : "Disconnected"}
                  </Badge>
                </div>

                <div className="space-y-3">
                  <h3 className="font-semibold text-gray-900">Konfigurasi Database</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm font-medium text-gray-700">Supabase URL</p>
                      <p className="text-sm font-mono text-gray-600 truncate">{supabaseUrl || "Not configured"}</p>
                    </div>

                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm font-medium text-gray-700">Supabase Anon Key</p>
                      <p className="text-sm font-mono text-gray-600">
                        {process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? "••••••••••••••••" : "Not configured"}
                      </p>
                    </div>
                  </div>
                </div>

                {isConnected && (
                  <div className="space-y-3">
                    <h3 className="font-semibold text-gray-900">Data Statistics</h3>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-sm font-medium text-blue-700">Jumlah Barcode</p>
                        <p className="text-2xl font-bold text-blue-600">{barcodeCount !== null ? barcodeCount : "—"}</p>
                      </div>

                      <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                        <p className="text-sm font-medium text-green-700">Jumlah Scan</p>
                        <p className="text-2xl font-bold text-green-600">{scanCount !== null ? scanCount : "—"}</p>
                      </div>

                      <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                        <p className="text-sm font-medium text-purple-700">Gift Eligible</p>
                        <p className="text-2xl font-bold text-purple-600">{giftCount !== null ? giftCount : "—"}</p>
                      </div>
                    </div>
                  </div>
                )}

                {!isConnected && (
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <div className="flex items-center gap-3">
                      <AlertCircle className="w-6 h-6 text-yellow-600" />
                      <div>
                        <h3 className="font-bold text-yellow-700">Troubleshooting</h3>
                        <ul className="text-sm text-yellow-600 space-y-1 mt-1">
                          <li>• Pastikan environment variables Supabase sudah dikonfigurasi dengan benar</li>
                          <li>• Periksa apakah tabel-tabel database sudah dibuat</li>
                          <li>• Pastikan koneksi internet Anda stabil</li>
                          <li>• Cek apakah service Supabase sedang mengalami gangguan</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                )}

                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <Shield className="w-6 h-6 text-green-600" />
                    <div>
                      <h3 className="font-bold text-green-700">Keamanan Database</h3>
                      <p className="text-sm text-green-600">
                        Data tersimpan aman di cloud Supabase dengan enkripsi dan Row Level Security (RLS).
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Database Schema */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Schema Database
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-2">Tabel barcodes</h3>
                <pre className="text-xs font-mono bg-gray-100 p-3 rounded overflow-x-auto">
                  {`CREATE TABLE barcodes (
  id SERIAL PRIMARY KEY,
  code VARCHAR(255) NOT NULL UNIQUE,
  is_redeemed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  redeemed_at TIMESTAMP WITH TIME ZONE
);`}
                </pre>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-2">Tabel users</h3>
                <pre className="text-xs font-mono bg-gray-100 p-3 rounded overflow-x-auto">
                  {`CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  scan_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);`}
                </pre>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-2">Tabel scans</h3>
                <pre className="text-xs font-mono bg-gray-100 p-3 rounded overflow-x-auto">
                  {`CREATE TABLE scans (
  id SERIAL PRIMARY KEY,
  barcode_id INTEGER REFERENCES barcodes(id),
  user_id INTEGER REFERENCES users(id),
  status VARCHAR(50) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);`}
                </pre>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-2">Tabel gift_eligibility</h3>
                <pre className="text-xs font-mono bg-gray-100 p-3 rounded overflow-x-auto">
                  {`CREATE TABLE gift_eligibility (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  is_claimed BOOLEAN DEFAULT FALSE,
  eligible_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  claimed_date TIMESTAMP WITH TIME ZONE
);`}
                </pre>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
