"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Search, Filter, Download, Calendar, User, CheckCircle, XCircle } from "lucide-react"
import Link from "next/link"

// Simulasi data yang sama dengan halaman utama (dalam produksi, gunakan state management atau database)
const getScannedHistory = () => {
  if (typeof window !== "undefined") {
    const stored = localStorage.getItem("piskulScanHistory")
    return stored ? JSON.parse(stored) : []
  }
  return []
}

export default function ScannedCodesPage() {
  const [scanHistory, setScanHistory] = useState<
    Array<{ barcode: string; name: string; timestamp: Date; status: "success" | "duplicate" }>
  >([])
  const [filteredHistory, setFilteredHistory] = useState<
    Array<{ barcode: string; name: string; timestamp: Date; status: "success" | "duplicate" }>
  >([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<"all" | "success" | "duplicate">("all")
  const [dateFilter, setDateFilter] = useState("")

  useEffect(() => {
    const history = getScannedHistory()
    // Convert timestamp strings back to Date objects
    const processedHistory = history.map((item: any) => ({
      ...item,
      timestamp: new Date(item.timestamp),
    }))
    setScanHistory(processedHistory)
    setFilteredHistory(processedHistory)
  }, [])

  useEffect(() => {
    let filtered = scanHistory

    // Filter by search term (barcode or name)
    if (searchTerm) {
      filtered = filtered.filter(
        (item) =>
          item.barcode.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.name.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Filter by status
    if (statusFilter !== "all") {
      filtered = filtered.filter((item) => item.status === statusFilter)
    }

    // Filter by date
    if (dateFilter) {
      const filterDate = new Date(dateFilter)
      filtered = filtered.filter((item) => {
        const itemDate = new Date(item.timestamp.toDateString())
        return itemDate.getTime() === filterDate.getTime()
      })
    }

    setFilteredHistory(filtered.reverse())
  }, [searchTerm, statusFilter, dateFilter, scanHistory])

  const exportToCSV = () => {
    const headers = ["Kode Kemasan", "Nama", "Tanggal", "Waktu", "Status"]
    const csvData = filteredHistory.map((item) => [
      item.barcode,
      item.name,
      item.timestamp.toLocaleDateString("id-ID"),
      item.timestamp.toLocaleTimeString("id-ID"),
      item.status === "success" ? "Berhasil" : "Duplikat",
    ])

    const csvContent = [headers, ...csvData].map((row) => row.map((field) => `"${field}"`).join(",")).join("\n")

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `kemasan-piskul-terscan-${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const stats = {
    total: scanHistory.length,
    successful: scanHistory.filter((h) => h.status === "success").length,
    duplicates: scanHistory.filter((h) => h.status === "duplicate").length,
    today: scanHistory.filter((h) => {
      const today = new Date().toDateString()
      return h.timestamp.toDateString() === today
    }).length,
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Kembali ke Scanner
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Kode Kemasan Ter-scan</h1>
                <p className="text-gray-600">Riwayat lengkap semua kemasan Piskul yang telah di-scan</p>
              </div>
            </div>
            <Button onClick={exportToCSV} className="flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export CSV
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Scan</p>
                  <p className="text-2xl font-bold text-blue-600">{stats.total}</p>
                </div>
                <Search className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Berhasil</p>
                  <p className="text-2xl font-bold text-green-600">{stats.successful}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Duplikat</p>
                  <p className="text-2xl font-bold text-yellow-600">{stats.duplicates}</p>
                </div>
                <XCircle className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Hari Ini</p>
                  <p className="text-2xl font-bold text-purple-600">{stats.today}</p>
                </div>
                <Calendar className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filter & Pencarian
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Cari Kode/Nama</label>
                <Input
                  placeholder="Cari berdasarkan kode atau nama..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Status</label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as "all" | "success" | "duplicate")}
                  className="w-full h-10 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">Semua Status</option>
                  <option value="success">Berhasil</option>
                  <option value="duplicate">Duplikat</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Tanggal</label>
                <Input
                  type="date"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  className="w-full"
                />
              </div>
              <div className="flex items-end">
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setStatusFilter("all")
                    setDateFilter("")
                  }}
                  className="w-full"
                >
                  Reset Filter
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Hasil Pencarian</CardTitle>
              <Badge variant="outline">
                {filteredHistory.length} dari {scanHistory.length} data
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {filteredHistory.length === 0 ? (
              <div className="text-center py-8">
                <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Tidak ada data yang ditemukan</p>
                <p className="text-sm text-gray-400">Coba ubah filter pencarian Anda</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {filteredHistory.map((item, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <Badge variant={item.status === "success" ? "default" : "secondary"} className="font-mono">
                        {item.barcode}
                      </Badge>
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-gray-500" />
                          <span className="text-sm font-medium text-gray-900">{item.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-500" />
                          <span className="text-xs text-gray-600">
                            {item.timestamp.toLocaleDateString("id-ID")} - {item.timestamp.toLocaleTimeString("id-ID")}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <Badge variant={item.status === "success" ? "default" : "destructive"}>
                        {item.status === "success" ? "Berhasil" : "Duplikat"}
                      </Badge>
                      {item.status === "success" && (
                        <span className="text-xs text-green-600 font-medium flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" />
                          Ter-redeem
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
