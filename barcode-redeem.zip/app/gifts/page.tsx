"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Gift, Crown, Star, CheckCircle, XCircle, Search, Calendar, Download } from "lucide-react"
import Link from "next/link"

interface GiftEligibleUser {
  name: string
  scanCount: number
  giftClaimed: boolean
  eligibleDate: Date
}

export default function GiftsPage() {
  const [giftEligibleUsers, setGiftEligibleUsers] = useState<GiftEligibleUser[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filter, setFilter] = useState<"all" | "claimed" | "unclaimed">("all")

  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("piskulGiftEligible")
      if (stored) {
        const data = JSON.parse(stored)
        setGiftEligibleUsers(
          data.map((item: any) => ({
            ...item,
            eligibleDate: new Date(item.eligibleDate),
          })),
        )
      }
    }
  }, [])

  const markGiftAsClaimed = (userName: string) => {
    const updatedUsers = giftEligibleUsers.map((user) =>
      user.name.toLowerCase() === userName.toLowerCase() ? { ...user, giftClaimed: true } : user,
    )
    setGiftEligibleUsers(updatedUsers)

    if (typeof window !== "undefined") {
      localStorage.setItem("piskulGiftEligible", JSON.stringify(updatedUsers))
    }
  }

  const markGiftAsUnclaimed = (userName: string) => {
    const updatedUsers = giftEligibleUsers.map((user) =>
      user.name.toLowerCase() === userName.toLowerCase() ? { ...user, giftClaimed: false } : user,
    )
    setGiftEligibleUsers(updatedUsers)

    if (typeof window !== "undefined") {
      localStorage.setItem("piskulGiftEligible", JSON.stringify(updatedUsers))
    }
  }

  const exportToCSV = () => {
    const headers = ["Nama", "Jumlah Scan", "Status Gift", "Tanggal Eligible"]
    const csvData = filteredUsers.map((user) => [
      user.name,
      user.scanCount.toString(),
      user.giftClaimed ? "Sudah Diklaim" : "Belum Diklaim",
      user.eligibleDate.toLocaleDateString("id-ID"),
    ])

    const csvContent = [headers, ...csvData].map((row) => row.map((field) => `"${field}"`).join(",")).join("\n")

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `gift-eligible-users-${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const filteredUsers = giftEligibleUsers.filter((user) => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter =
      filter === "all" || (filter === "claimed" && user.giftClaimed) || (filter === "unclaimed" && !user.giftClaimed)

    return matchesSearch && matchesFilter
  })

  const stats = {
    total: giftEligibleUsers.length,
    claimed: giftEligibleUsers.filter((u) => u.giftClaimed).length,
    unclaimed: giftEligibleUsers.filter((u) => !u.giftClaimed).length,
    totalScans: giftEligibleUsers.reduce((sum, u) => sum + u.scanCount, 0),
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Kembali ke Scanner
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                  <Crown className="w-6 h-6 text-yellow-600" />
                  Gift Eligible Users
                </h1>
                <p className="text-gray-600">Kelola pelanggan yang berhak mendapat gift</p>
              </div>
            </div>
            <Button onClick={exportToCSV} className="flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export CSV
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Eligible</p>
                  <p className="text-2xl font-bold text-purple-600">{stats.total}</p>
                </div>
                <Crown className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Gift Diklaim</p>
                  <p className="text-2xl font-bold text-green-600">{stats.claimed}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Belum Diklaim</p>
                  <p className="text-2xl font-bold text-orange-600">{stats.unclaimed}</p>
                </div>
                <Gift className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Scan</p>
                  <p className="text-2xl font-bold text-blue-600">{stats.totalScans}</p>
                </div>
                <Star className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5" />
              Filter & Pencarian
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Cari Nama</label>
                <Input
                  placeholder="Cari berdasarkan nama..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Status Gift</label>
                <select
                  value={filter}
                  onChange={(e) => setFilter(e.target.value as "all" | "claimed" | "unclaimed")}
                  className="w-full h-10 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">Semua Status</option>
                  <option value="unclaimed">Belum Diklaim</option>
                  <option value="claimed">Sudah Diklaim</option>
                </select>
              </div>
              <div className="flex items-end">
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setFilter("all")
                  }}
                  className="w-full"
                >
                  Reset Filter
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Gift Eligible Users List */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Daftar Pelanggan Gift Eligible</CardTitle>
              <Badge variant="outline">
                {filteredUsers.length} dari {giftEligibleUsers.length} pelanggan
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {filteredUsers.length === 0 ? (
              <div className="text-center py-8">
                <Gift className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Tidak ada pelanggan yang ditemukan</p>
                <p className="text-sm text-gray-400">Coba ubah filter pencarian Anda</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredUsers.map((user, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      user.giftClaimed
                        ? "bg-green-50 border-green-200"
                        : "bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-300"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div
                          className={`w-12 h-12 rounded-full flex items-center justify-center ${
                            user.giftClaimed ? "bg-green-500" : "bg-gradient-to-br from-yellow-400 to-orange-500"
                          }`}
                        >
                          {user.giftClaimed ? (
                            <CheckCircle className="w-6 h-6 text-white" />
                          ) : (
                            <Gift className="w-6 h-6 text-white" />
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-bold text-gray-900">{user.name}</h3>
                            <Badge
                              className={`${
                                user.giftClaimed ? "bg-green-500" : "bg-gradient-to-r from-yellow-400 to-orange-500"
                              } text-white`}
                            >
                              <Crown className="w-3 h-3 mr-1" />
                              {user.giftClaimed ? "Gift Diklaim" : "Gift Ready"}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4" />
                              <span>{user.scanCount} scan berhasil</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              <span>Eligible: {user.eligibleDate.toLocaleDateString("id-ID")}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {user.giftClaimed ? (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => markGiftAsUnclaimed(user.name)}
                            className="flex items-center gap-2"
                          >
                            <XCircle className="w-4 h-4" />
                            Batalkan Klaim
                          </Button>
                        ) : (
                          <Button
                            onClick={() => markGiftAsClaimed(user.name)}
                            className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 flex items-center gap-2"
                          >
                            <Gift className="w-4 h-4" />
                            Berikan Gift
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
