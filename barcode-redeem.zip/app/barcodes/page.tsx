"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { QrCode, Download, Printer, Shield, Lock, ArrowLeft } from "lucide-react"
import { useEffect, useRef } from "react"
import { generateSecureToken } from "@/lib/crypto"
import Link from "next/link"

const BARCODE_LIST = [
  "PSK001-PISKUL-2024",
  "PSK002-PISKUL-2024",
  "PSK003-PISKUL-2024",
  "PSK004-PISKUL-2024",
  "PSK005-PISKUL-2024",
  "PSK006-PISKUL-2024",
  "PSK007-PISKUL-2024",
  "PSK008-PISKUL-2024",
  "PSK009-PISKUL-2024",
  "PSK010-PISKUL-2024",
  "PSK011-PISKUL-2024",
  "PSK012-PISKUL-2024",
  "PSK013-PISKUL-2024",
  "PSK014-PISKUL-2024",
  "PSK015-PISKUL-2024",
  "PSK016-PISKUL-2024",
  "PSK017-PISKUL-2024",
  "PSK018-PISKUL-2024",
  "PSK019-PISKUL-2024",
  "PSK020-PISKUL-2024",
  "PSK021-PISKUL-2024",
  "PSK022-PISKUL-2024",
  "PSK023-PISKUL-2024",
  "PSK024-PISKUL-2024",
  "PSK025-PISKUL-2024",
  "PSK026-PISKUL-2024",
  "PSK027-PISKUL-2024",
  "PSK028-PISKUL-2024",
  "PSK029-PISKUL-2024",
  "PSK030-PISKUL-2024",
  "PSK031-PISKUL-2024",
  "PSK032-PISKUL-2024",
  "PSK033-PISKUL-2024",
  "PSK034-PISKUL-2024",
  "PSK035-PISKUL-2024",
  "PSK036-PISKUL-2024",
  "PSK037-PISKUL-2024",
  "PSK038-PISKUL-2024",
  "PSK039-PISKUL-2024",
  "PSK040-PISKUL-2024",
  "PSK041-PISKUL-2024",
  "PSK042-PISKUL-2024",
  "PSK043-PISKUL-2024",
  "PSK044-PISKUL-2024",
  "PSK045-PISKUL-2024",
  "PSK046-PISKUL-2024",
  "PSK047-PISKUL-2024",
  "PSK048-PISKUL-2024",
  "PSK049-PISKUL-2024",
  "PSK050-PISKUL-2024",
]

export default function BarcodesPage() {
  const canvasRefs = useRef<(HTMLCanvasElement | null)[]>([])

  const generateQRCode = async (barcode: string, canvas: HTMLCanvasElement) => {
    try {
      const QRCode = (await import("qrcode")).default

      // Generate encrypted secure token instead of plain barcode
      const secureToken = generateSecureToken(barcode)

      await QRCode.toCanvas(canvas, secureToken, {
        width: 200,
        margin: 2,
        color: {
          dark: "#000000",
          light: "#FFFFFF",
        },
        errorCorrectionLevel: "M",
      })
    } catch (error) {
      console.error("Error generating QR code:", error)
    }
  }

  useEffect(() => {
    BARCODE_LIST.forEach((barcode, index) => {
      const canvas = canvasRefs.current[index]
      if (canvas) {
        generateQRCode(barcode, canvas)
      }
    })
  }, [])

  const handlePrint = () => {
    window.print()
  }

  const downloadAllQRCodes = () => {
    const zip = new (window as any).JSZip()

    BARCODE_LIST.forEach((barcode, index) => {
      const canvas = canvasRefs.current[index]
      if (canvas) {
        const dataURL = canvas.toDataURL("image/png")
        const base64Data = dataURL.split(",")[1]
        zip.file(`${barcode}-encrypted.png`, base64Data, { base64: true })
      }
    })

    zip.generateAsync({ type: "blob" }).then((content: Blob) => {
      const url = URL.createObjectURL(content)
      const a = document.createElement("a")
      a.href = url
      a.download = "kemasan-piskul-encrypted-qrcodes.zip"
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b print:hidden">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="outline" size="sm" className="flex items-center gap-2 print:hidden">
                  <ArrowLeft className="w-4 h-4" />
                  Kembali ke Scanner
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                  <Shield className="w-6 h-6 text-green-600" />
                  QR Codes Kemasan Piskul (Encrypted)
                </h1>
                <p className="text-gray-600">50 QR Code terenkripsi untuk keamanan maksimal</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Button onClick={handlePrint} className="flex items-center gap-2">
                <Printer className="w-4 h-4" />
                Print
              </Button>
              <Button onClick={downloadAllQRCodes} variant="outline" className="flex items-center gap-2">
                <Download className="w-4 h-4" />
                Download ZIP
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Security Notice */}
      <div className="max-w-6xl mx-auto p-4 print:hidden">
        <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                <Lock className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-green-600" />
                  QR Code Terenkripsi & Aman
                </h3>
                <p className="text-sm text-gray-600">
                  QR Code ini menggunakan enkripsi khusus dan tidak dapat dibaca manual. Hanya aplikasi resmi yang dapat
                  memproses kode ini.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* QR Codes Grid */}
      <div className="max-w-6xl mx-auto p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 print:grid-cols-5 print:gap-2">
          {BARCODE_LIST.map((barcode, index) => (
            <Card key={barcode} className="text-center print:break-inside-avoid print:shadow-none">
              <CardHeader className="pb-2 print:pb-1">
                <CardTitle className="text-sm font-medium text-gray-700 print:text-xs flex items-center justify-center gap-1">
                  <Lock className="w-3 h-3 text-green-600" />
                  Kemasan Piskul #{String(index + 1).padStart(2, "0")}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 print:space-y-1">
                <div className="flex justify-center">
                  <canvas
                    ref={(el) => (canvasRefs.current[index] = el)}
                    className="border border-gray-200 rounded print:border-gray-400"
                  />
                </div>
                <div className="bg-gray-50 p-2 rounded print:bg-gray-100 print:p-1">
                  <p className="text-xs font-mono text-gray-600 break-all print:text-[10px]">{barcode}</p>
                  <p className="text-[10px] text-green-600 font-medium flex items-center justify-center gap-1 mt-1">
                    <Shield className="w-2 h-2" />
                    Encrypted
                  </p>
                </div>
                <div className="flex items-center justify-center gap-1 text-xs text-gray-500 print:hidden">
                  <QrCode className="w-3 h-3" />
                  <span>Scan dengan app resmi</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Instructions */}
        <Card className="mt-8 print:hidden">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-green-600" />
              Petunjuk Redeem Kemasan Piskul (Sistem Terenkripsi)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Untuk Admin:</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Gunakan aplikasi Redeem Kemasan Piskul resmi</li>
                  <li>• Login dengan kredensial admin yang valid</li>
                  <li>• Scan QR code terenkripsi dengan scanner app</li>
                  <li>• Sistem akan dekripsi dan validasi otomatis</li>
                  <li>• Data tersimpan aman di database cloud</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Keamanan Sistem:</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• QR Code menggunakan enkripsi XOR + Base64</li>
                  <li>• Token memiliki timestamp dan expiry</li>
                  <li>• Tidak dapat dibaca dengan scanner biasa</li>
                  <li>• Data tersimpan di database Supabase</li>
                  <li>• Validasi server-side untuk setiap scan</li>
                </ul>
              </div>
            </div>
            <div className="bg-red-50 p-3 rounded-lg border border-red-200">
              <p className="text-sm text-red-700">
                <strong>⚠️ Peringatan Keamanan:</strong> QR Code ini menggunakan enkripsi khusus dan hanya dapat diproses
                oleh aplikasi resmi Redeem Kemasan Piskul. Jangan coba scan dengan aplikasi lain karena tidak akan
                berfungsi.
              </p>
            </div>
            <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-700">
                <strong>💾 Database Integration:</strong> Semua data redeem tersimpan aman di database cloud dan tidak
                dapat dimanipulasi dari browser. Sistem menggunakan validasi server-side untuk mencegah fraud.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          body { margin: 0; }
          .print\\:hidden { display: none !important; }
          .print\\:grid-cols-5 { grid-template-columns: repeat(5, minmax(0, 1fr)) !important; }
          .print\\:gap-2 { gap: 0.5rem !important; }
          .print\\:break-inside-avoid { break-inside: avoid; }
          .print\\:shadow-none { box-shadow: none !important; }
          .print\\:border-gray-400 { border-color: #9ca3af !important; }
          .print\\:bg-gray-100 { background-color: #f3f4f6 !important; }
          .print\\:p-1 { padding: 0.25rem !important; }
          .print\\:pb-1 { padding-bottom: 0.25rem !important; }
          .print\\:space-y-1 > * + * { margin-top: 0.25rem !important; }
          .print\\:text-xs { font-size: 0.75rem !important; }
          .print\\:text-\\[10px\\] { font-size: 10px !important; }
        }
      `}</style>
    </div>
  )
}
