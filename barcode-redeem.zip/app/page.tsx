"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import Link from "next/link"
import {
  Camera,
  LogOut,
  RotateCcw,
  Scan,
  User,
  CheckCircle,
  XCircle,
  AlertCircle,
  QrCode,
  Search,
  Gift,
  Crown,
  Star,
  Trash2,
  Shield,
  Database,
  Plus,
  RefreshCw,
} from "lucide-react"
import { verifySecureToken, isValidPiskulBarcode } from "@/lib/crypto"
import {
  getBarcodeByCode,
  getUserByName,
  createUser,
  updateUserScanCount,
  markBarcodeAsRedeemed,
  createScan,
  getScansHistory,
  deleteScan,
  getGiftEligibleUsers,
  createGiftEligibility,
  markGiftAsClaimed,
  type GiftEligibility,
} from "@/lib/supabase"

const AdminCredentials = {
  username: "Admin#123",
  password: "Admin#5758",
}

export default function BarcodeRedeemApp() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [barcode, setBarcode] = useState("")
  const [name, setName] = useState("")
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error" | "warning" | "info">("info")
  const [scanning, setScanning] = useState(false)
  const [stats, setStats] = useState({ total: 0, successful: 0, duplicates: 0 })
  const [showAllScanned, setShowAllScanned] = useState(false)
  const [showGiftNotification, setShowGiftNotification] = useState(false)
  const [newGiftEligible, setNewGiftEligible] = useState<string>("")
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<number | null>(null)
  const [scanHistory, setScanHistory] = useState<any[]>([])
  const [giftEligibleUsers, setGiftEligibleUsers] = useState<GiftEligibility[]>([])
  const [loading, setLoading] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const scannerRef = useRef<any>(null)

  const loadData = async () => {
    try {
      setLoading(true)
      const [scansData, giftData] = await Promise.all([getScansHistory(), getGiftEligibleUsers()])

      setScanHistory(scansData)
      setGiftEligibleUsers(giftData)
      updateStatsFromData(scansData)
    } catch (error) {
      console.error("Error loading data:", error)
      showMessage("Gagal memuat data dari database", "error")
    } finally {
      setLoading(false)
    }
  }

  const updateStatsFromData = (scans: any[]) => {
    setStats({
      total: scans.length,
      successful: scans.filter((s) => s.status === "success").length,
      duplicates: scans.filter((s) => s.status === "duplicate").length,
    })
  }

  const checkGiftEligibility = async (userName: string, userId: number) => {
    if (!userName.trim() || userName === "Tidak ada nama") return

    // Hitung jumlah scan berhasil untuk user ini dari database
    const userSuccessfulScans = scanHistory.filter(
      (item) => item.users?.name.toLowerCase() === userName.toLowerCase() && item.status === "success",
    ).length

    if (userSuccessfulScans >= 10) {
      // Cek apakah user sudah ada di gift eligibility
      const existingGift = giftEligibleUsers.find((gift) => gift.user_id === userId)

      if (!existingGift) {
        // Buat gift eligibility baru
        const newGift = await createGiftEligibility(userId)
        if (newGift) {
          setGiftEligibleUsers((prev) => [...prev, newGift])
          setNewGiftEligible(userName)
          setShowGiftNotification(true)
        }
      }
    }
  }

  const showMessage = (text: string, type: "success" | "error" | "warning" | "info" = "info") => {
    setMessage(text)
    setMessageType(type)
    setTimeout(() => setMessage(""), 5000)
  }

  const handleLogin = () => {
    if (username === AdminCredentials.username && password === AdminCredentials.password) {
      setLoggedIn(true)
      setMessage("")
      showMessage("Login berhasil! Selamat datang Admin.", "success")
      loadData()
    } else {
      showMessage("Login gagal. Username atau password salah.", "error")
    }
  }

  const handleLogout = () => {
    setLoggedIn(false)
    setUsername("")
    setPassword("")
    setMessage("")
    stopScanning()
  }

  const processBarcode = async (barcodeValue: string, nameValue = "") => {
    if (!barcodeValue.trim()) {
      showMessage("Silakan masukkan kode kemasan Piskul terlebih dahulu.", "warning")
      return
    }

    setLoading(true)

    try {
      // Coba dekripsi token terlebih dahulu
      let actualBarcode = verifySecureToken(barcodeValue)

      // Jika gagal dekripsi, coba sebagai barcode biasa
      if (!actualBarcode) {
        actualBarcode = barcodeValue
        console.log("Using barcode as plain text:", actualBarcode)
      } else {
        console.log("Successfully decrypted barcode:", actualBarcode)
      }

      if (!isValidPiskulBarcode(actualBarcode)) {
        showMessage(
          `Kode kemasan Piskul "${actualBarcode}" tidak valid. Format yang benar: PSK001-PISKUL-2024`,
          "error",
        )
        return
      }

      const finalName = nameValue.trim() || "Tidak ada nama"

      // Cek barcode di database
      console.log("Checking barcode in database:", actualBarcode)
      const barcodeData = await getBarcodeByCode(actualBarcode)

      if (!barcodeData) {
        showMessage(
          `Kode kemasan Piskul "${actualBarcode}" tidak ditemukan dalam database. Pastikan kode sudah terdaftar dalam sistem. Silakan kunjungi halaman "Setup DB" untuk menambahkan barcode ke database.`,
          "error",
        )
        return
      }

      console.log("Barcode found in database:", barcodeData)

      // Cek atau buat user
      let userData = await getUserByName(finalName)
      if (!userData) {
        console.log("User not found, creating new user:", finalName)
        userData = await createUser(finalName)
        if (!userData) {
          showMessage("Gagal membuat data pengguna. Silakan coba lagi.", "error")
          return
        }
        console.log("New user created:", userData)
      } else {
        console.log("Existing user found:", userData)
      }

      let scanStatus: "success" | "duplicate" = "success"

      if (barcodeData.is_redeemed) {
        scanStatus = "duplicate"
        showMessage(`Kemasan Piskul "${actualBarcode}" sudah pernah di-redeem sebelumnya.`, "warning")
      } else {
        // Mark barcode sebagai redeemed
        const redeemSuccess = await markBarcodeAsRedeemed(barcodeData.id)
        if (!redeemSuccess) {
          showMessage("Gagal menandai barcode sebagai redeemed. Silakan coba lagi.", "error")
          return
        }

        // Update user scan count
        const newScanCount = userData.scan_count + 1
        const updateSuccess = await updateUserScanCount(userData.id, newScanCount)
        if (!updateSuccess) {
          showMessage("Gagal mengupdate jumlah scan pengguna. Silakan coba lagi.", "error")
          return
        }

        showMessage(`Kemasan Piskul "${actualBarcode}" berhasil di-redeem untuk ${finalName}!`, "success")

        // Cek eligibilitas gift
        await checkGiftEligibility(finalName, userData.id)
      }

      // Buat record scan
      const newScan = await createScan(barcodeData.id, userData.id, scanStatus)
      if (newScan) {
        setScanHistory((prev) => [newScan, ...prev])
        updateStatsFromData([newScan, ...scanHistory])
        console.log("Scan record created successfully:", newScan)
      } else {
        showMessage("Berhasil memproses barcode, tetapi gagal menyimpan riwayat scan.", "warning")
      }
    } catch (error) {
      console.error("Error processing barcode:", error)
      showMessage(
        `Terjadi kesalahan saat memproses barcode: ${error instanceof Error ? error.message : "Unknown error"}`,
        "error",
      )
    } finally {
      setLoading(false)
      setBarcode("")
      setName("")
    }
  }

  // Perbaiki fungsi handleDeleteScan
  const handleDeleteScan = async (scanId: number) => {
    try {
      setLoading(true)
      showMessage("Menghapus scan dan menyinkronkan data...", "info")

      const success = await deleteScan(scanId)

      if (success) {
        // Sinkronisasi database untuk memastikan konsistensi
        const { syncDatabaseData } = await import("@/lib/supabase")
        await syncDatabaseData()

        // Reload data untuk memastikan konsistensi
        await loadData()
        setShowDeleteConfirm(null)
        showMessage("✅ Scan berhasil dihapus dan data telah disinkronkan!", "success")
      } else {
        showMessage("❌ Gagal menghapus scan dari database.", "error")
      }
    } catch (error) {
      console.error("Error deleting scan:", error)
      showMessage("❌ Terjadi kesalahan saat menghapus scan.", "error")
    } finally {
      setLoading(false)
    }
  }

  // Tambahkan fungsi untuk sinkronisasi manual
  const handleSyncDatabase = async () => {
    try {
      setLoading(true)
      showMessage("Menyinkronkan database...", "info")

      const { syncDatabaseData } = await import("@/lib/supabase")
      const success = await syncDatabaseData()

      if (success) {
        await loadData()
        showMessage("✅ Database berhasil disinkronkan!", "success")
      } else {
        showMessage("❌ Gagal menyinkronkan database.", "error")
      }
    } catch (error) {
      console.error("Error syncing database:", error)
      showMessage("❌ Terjadi kesalahan saat menyinkronkan database.", "error")
    } finally {
      setLoading(false)
    }
  }

  const handleManualScan = () => {
    processBarcode(barcode, name)
  }

  const handleReset = async () => {
    if (
      confirm(
        "⚠️ PERINGATAN RESET DATABASE ⚠️\n\n" +
          "Apakah Anda yakin ingin mereset SEMUA data di database?\n\n" +
          "Tindakan ini akan:\n" +
          "• Menghapus SEMUA riwayat scan\n" +
          "• Menghapus SEMUA data pengguna\n" +
          "• Menghapus SEMUA gift eligibility\n" +
          "• Reset status SEMUA barcode\n\n" +
          "TINDAKAN INI TIDAK DAPAT DIBATALKAN!\n\n" +
          "Ketik 'RESET' untuk melanjutkan:",
      )
    ) {
      const confirmation = prompt("Ketik 'RESET' untuk mengkonfirmasi reset database:")

      if (confirmation === "RESET") {
        try {
          setLoading(true)
          showMessage("Memulai reset database... Mohon tunggu.", "info")

          const { deleteAllScans } = await import("@/lib/supabase")
          const success = await deleteAllScans()

          if (success) {
            // Reload data setelah reset
            await loadData()
            showMessage("✅ Database berhasil direset! Semua data telah dihapus dan barcode direset.", "success")
          } else {
            showMessage("❌ Gagal mereset database. Silakan coba lagi atau periksa koneksi database.", "error")
          }
        } catch (error) {
          console.error("Error resetting database:", error)
          showMessage(
            `❌ Terjadi kesalahan saat mereset database: ${error instanceof Error ? error.message : "Unknown error"}`,
            "error",
          )
        } finally {
          setLoading(false)
        }
      } else {
        showMessage("Reset database dibatalkan.", "info")
      }
    }
  }

  const handleFullReset = async () => {
    if (
      confirm(
        "🚨 RESET LENGKAP DATABASE 🚨\n\n" +
          "Ini akan menghapus SEMUA DATA termasuk:\n" +
          "• Semua barcode dari database\n" +
          "• Semua pengguna\n" +
          "• Semua riwayat scan\n" +
          "• Semua gift eligibility\n\n" +
          "Database akan kembali kosong!\n\n" +
          "SANGAT BERBAHAYA - TIDAK DAPAT DIBATALKAN!",
      )
    ) {
      const confirmation = prompt("Ketik 'DELETE ALL' untuk mengkonfirmasi:")

      if (confirmation === "DELETE ALL") {
        try {
          setLoading(true)
          showMessage("Menghapus semua data dari database... Mohon tunggu.", "info")

          const { resetAllData } = await import("@/lib/supabase")
          const success = await resetAllData()

          if (success) {
            // Clear local state
            setScanHistory([])
            setGiftEligibleUsers([])
            setStats({ total: 0, successful: 0, duplicates: 0 })

            showMessage("✅ Semua data berhasil dihapus dari database!", "success")
          } else {
            showMessage("❌ Gagal menghapus data dari database.", "error")
          }
        } catch (error) {
          console.error("Error in full reset:", error)
          showMessage(`❌ Terjadi kesalahan: ${error instanceof Error ? error.message : "Unknown error"}`, "error")
        } finally {
          setLoading(false)
        }
      } else {
        showMessage("Reset lengkap dibatalkan.", "info")
      }
    }
  }

  const startScanning = async () => {
    setMessage("")
    setScanning(true)

    try {
      const { default: QrScanner } = await import("qr-scanner")

      if (videoRef.current) {
        if (scannerRef.current) {
          scannerRef.current.destroy()
        }

        scannerRef.current = new QrScanner(
          videoRef.current,
          (result) => {
            console.log("QR Code detected:", result.data)
            processBarcode(result.data, name)
            stopScanning()
          },
          {
            returnDetailedScanResult: true,
            highlightScanRegion: true,
            highlightCodeOutline: true,
            preferredCamera: "environment",
            maxScansPerSecond: 5,
          },
        )

        await scannerRef.current.start()
        showMessage("Kamera aktif. Arahkan ke QR code kemasan Piskul untuk memindai.", "info")
      }
    } catch (error) {
      console.error("Scanner error:", error)
      showMessage("Gagal mengakses kamera. Pastikan izin kamera telah diberikan dan gunakan HTTPS.", "error")
      setScanning(false)
    }
  }

  const stopScanning = () => {
    if (scannerRef.current) {
      scannerRef.current.stop()
    }
    setScanning(false)
  }

  const handleMarkGiftAsClaimed = async (userId: number, userName: string) => {
    try {
      const success = await markGiftAsClaimed(userId)
      if (success) {
        setGiftEligibleUsers((prev) =>
          prev.map((gift) =>
            gift.user_id === userId ? { ...gift, is_claimed: true, claimed_date: new Date().toISOString() } : gift,
          ),
        )
        showMessage(`Gift untuk ${userName} telah ditandai sebagai diklaim!`, "success")
      }
    } catch (error) {
      console.error("Error marking gift as claimed:", error)
      showMessage("Gagal menandai gift sebagai diklaim.", "error")
    }
  }

  useEffect(() => {
    return () => {
      if (scannerRef.current) {
        scannerRef.current.destroy()
      }
    }
  }, [])

  // Tambahkan useEffect baru untuk memeriksa koneksi database
  useEffect(() => {
    if (loggedIn) {
      // Test koneksi database saat login
      const testConnection = async () => {
        try {
          const { testDatabaseConnection } = await import("@/lib/supabase")
          const connected = await testDatabaseConnection()

          if (!connected) {
            showMessage(
              "Peringatan: Tidak dapat terhubung ke database Supabase. Data mungkin tidak tersimpan dengan benar. Silakan periksa halaman Database Status.",
              "warning",
            )
          }
        } catch (error) {
          console.error("Error testing database connection:", error)
        }
      }

      testConnection()
    }
  }, [loggedIn])

  const toggleShowAllScanned = () => {
    setShowAllScanned(!showAllScanned)
  }

  // Login Screen
  if (!loggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <Card className="w-full max-w-md shadow-lg">
          <CardHeader className="text-center space-y-2">
            <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
              <User className="w-8 h-8 text-blue-600" />
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900 flex items-center justify-center gap-2">
              <Shield className="w-6 h-6 text-green-600" />
              Redeem Kemasan Piskul
            </CardTitle>
            <p className="text-gray-600">Sistem terenkripsi dengan database cloud</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <Input
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleLogin()}
                className="h-12"
              />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleLogin()}
                className="h-12"
              />
              <Button onClick={handleLogin} className="w-full h-12 text-lg">
                Login
              </Button>
            </div>
            {message && (
              <div
                className={`p-3 rounded-md border ${
                  messageType === "error"
                    ? "bg-red-50 border-red-200 text-red-700"
                    : "bg-blue-50 border-blue-200 text-blue-700"
                }`}
              >
                <p className="text-sm">{message}</p>
              </div>
            )}
            <div className="bg-green-50 p-3 rounded-lg border border-green-200">
              <div className="flex items-center gap-2 mb-2">
                <Database className="w-4 h-4 text-green-600" />
                <span className="text-sm font-medium text-green-700">Database Integration</span>
              </div>
              <p className="text-xs text-green-600">Data tersimpan aman di Supabase cloud database</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Main Application
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-600">
                <Trash2 className="w-5 h-5" />
                Konfirmasi Hapus Scan
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                Apakah Anda yakin ingin menghapus scan ini dari database? Tindakan ini tidak dapat dibatalkan dan akan
                mempengaruhi:
              </p>
              <ul className="text-sm text-gray-600 space-y-1 ml-4">
                <li>• Status barcode akan kembali tersedia</li>
                <li>• Jumlah scan pelanggan akan berkurang</li>
                <li>• Status gift eligible mungkin berubah</li>
                <li>• Data akan dihapus permanen dari database</li>
              </ul>
              <div className="flex gap-3">
                <Button
                  variant="destructive"
                  onClick={() => handleDeleteScan(showDeleteConfirm)}
                  className="flex-1"
                  disabled={loading}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  {loading ? "Menghapus..." : "Ya, Hapus"}
                </Button>
                <Button variant="outline" onClick={() => setShowDeleteConfirm(null)} className="flex-1">
                  Batal
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Gift Notification Modal */}
      {showGiftNotification && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-gradient-to-br from-yellow-50 to-orange-50 border-2 border-yellow-300 shadow-2xl">
            <CardHeader className="text-center space-y-4">
              <div className="mx-auto w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center animate-bounce">
                <Gift className="w-10 h-10 text-white" />
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-bold text-gray-900 flex items-center justify-center gap-2">
                  <Crown className="w-6 h-6 text-yellow-600" />
                  Selamat!
                  <Crown className="w-6 h-6 text-yellow-600" />
                </h2>
                <p className="text-lg font-semibold text-orange-700">{newGiftEligible}</p>
                <p className="text-gray-700">Telah mencapai 10 scan berhasil!</p>
              </div>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="bg-white p-4 rounded-lg border border-yellow-200">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Star className="w-5 h-5 text-yellow-500" />
                  <span className="font-bold text-gray-900">BERHAK MENDAPAT GIFT!</span>
                  <Star className="w-5 h-5 text-yellow-500" />
                </div>
                <p className="text-sm text-gray-600">
                  Pelanggan ini telah mengumpulkan 10 kemasan Piskul dan berhak mendapatkan hadiah spesial!
                </p>
              </div>
              <div className="flex gap-3">
                <Button
                  onClick={() => {
                    const giftUser = giftEligibleUsers.find((g) => g.users?.name === newGiftEligible)
                    if (giftUser) {
                      handleMarkGiftAsClaimed(giftUser.user_id, newGiftEligible)
                    }
                    setShowGiftNotification(false)
                  }}
                  className="flex-1 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                >
                  <Gift className="w-4 h-4 mr-2" />
                  Berikan Gift
                </Button>
                <Button variant="outline" onClick={() => setShowGiftNotification(false)} className="flex-1">
                  Nanti Saja
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <Shield className="w-6 h-6 text-green-600" />
                Redeem Kemasan Piskul
              </h1>
              <p className="text-gray-600 flex items-center gap-2">
                <Database className="w-4 h-4 text-blue-600" />
                Dashboard Admin - Database Supabase
              </p>
            </div>
            <div className="flex gap-3">
              <Link href="/barcodes">
                <Button variant="outline" className="flex items-center gap-2">
                  <QrCode className="w-4 h-4" />
                  QR Codes
                </Button>
              </Link>
              <Link href="/scanned">
                <Button variant="outline" className="flex items-center gap-2">
                  <Search className="w-4 h-4" />
                  Riwayat Scan
                </Button>
              </Link>
              <Link href="/gifts">
                <Button variant="outline" className="flex items-center gap-2 relative">
                  <Gift className="w-4 h-4" />
                  Gift Eligible
                  {giftEligibleUsers.filter((u) => !u.is_claimed).length > 0 && (
                    <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-1 min-w-[20px] h-5">
                      {giftEligibleUsers.filter((u) => !u.is_claimed).length}
                    </Badge>
                  )}
                </Button>
              </Link>

              {/* Tambahkan link ke halaman database status */}
              <Link href="/database-status">
                <Button variant="outline" className="flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  Database
                </Button>
              </Link>

              {/* Tambahkan link ke halaman setup database */}
              <Link href="/database-setup">
                <Button
                  variant="outline"
                  className="flex items-center gap-2 text-green-600 border-green-200 hover:bg-green-50"
                >
                  <Plus className="w-4 h-4" />
                  Setup DB
                </Button>
              </Link>

              <Button variant="outline" onClick={loadData} disabled={loading} className="flex items-center gap-2">
                <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
                {loading ? "Loading..." : "Refresh Data"}
              </Button>
              {/* Di bagian header, tambahkan tombol sync setelah tombol refresh */}
              <Button
                variant="outline"
                onClick={handleSyncDatabase}
                disabled={loading}
                className="flex items-center gap-2"
              >
                <Database className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
                {loading ? "Syncing..." : "Sync DB"}
              </Button>

              <Button variant="outline" onClick={handleLogout} className="flex items-center gap-2">
                <LogOut className="w-4 h-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Scan</p>
                  <p className="text-2xl font-bold text-blue-600">{stats.total}</p>
                </div>
                <Scan className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Berhasil</p>
                  <p className="text-2xl font-bold text-green-600">{stats.successful}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Duplikat</p>
                  <p className="text-2xl font-bold text-yellow-600">{stats.duplicates}</p>
                </div>
                <XCircle className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Gift Eligible</p>
                  <p className="text-2xl font-bold text-purple-600">{giftEligibleUsers.length}</p>
                </div>
                <Gift className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Security Status */}
        <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">Sistem Keamanan Aktif</h3>
                  <p className="text-sm text-gray-600">QR Code terenkripsi + Database cloud Supabase</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge className="bg-green-500 text-white">
                  <Database className="w-3 h-3 mr-1" />
                  Database Online
                </Badge>
                <Badge className="bg-blue-500 text-white">
                  <Shield className="w-3 h-3 mr-1" />
                  Encrypted
                </Badge>

                {/* Tambahkan tombol untuk memeriksa status database */}
                <Link href="/database-status">
                  <Button variant="outline" size="sm" className="ml-2">
                    <Database className="w-3 h-3 mr-1" />
                    Cek Database
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Gift Alert Banner */}
        {giftEligibleUsers.filter((u) => !u.is_claimed).length > 0 && (
          <Card className="border-2 border-yellow-300 bg-gradient-to-r from-yellow-50 to-orange-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                    <Gift className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">
                      {giftEligibleUsers.filter((u) => !u.is_claimed).length} Pelanggan Berhak Mendapat Gift!
                    </h3>
                    <p className="text-sm text-gray-600">Ada pelanggan yang telah mengumpulkan 10+ kemasan Piskul</p>
                  </div>
                </div>
                <Link href="/gifts">
                  <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                    <Crown className="w-4 h-4 mr-2" />
                    Lihat Detail
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Main Scanner Interface */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Scan className="w-5 h-5" />
              Scanner Kemasan Piskul (Encrypted)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <Input
                placeholder="Scan QR code terenkripsi atau masukkan kode manual"
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleManualScan()}
                className="h-12 text-lg"
                disabled={loading}
              />
              <Input
                placeholder="Masukkan nama penerima kemasan Piskul"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-12 text-lg"
                disabled={loading}
              />

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <Button
                  onClick={handleManualScan}
                  disabled={!barcode.trim() || loading}
                  className="h-12 flex items-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  {loading ? "Processing..." : "Redeem Kemasan"}
                </Button>

                <Button
                  onClick={scanning ? stopScanning : startScanning}
                  variant={scanning ? "destructive" : "default"}
                  className="h-12 flex items-center gap-2"
                  disabled={loading}
                >
                  <Camera className="w-4 h-4" />
                  {scanning ? "Stop Kamera" : "Buka Kamera"}
                </Button>

                <div className="relative">
                  <Button
                    variant="outline"
                    onClick={handleReset}
                    className="h-12 flex items-center gap-2 w-full"
                    disabled={loading}
                  >
                    <RotateCcw className="w-4 h-4" />
                    Reset Scans
                  </Button>
                </div>
              </div>

              {/* Tambahkan tombol reset lengkap di bawah */}
              <div className="mt-4">
                <Button
                  variant="destructive"
                  onClick={handleFullReset}
                  className="w-full h-10 flex items-center gap-2 text-sm"
                  disabled={loading}
                >
                  <XCircle className="w-4 h-4" />🚨 Reset Lengkap Database (BERBAHAYA)
                </Button>
              </div>
            </div>

            {scanning && (
              <div className="space-y-3">
                <Separator />
                <div className="bg-gray-50 p-4 rounded-lg">
                  <video
                    ref={videoRef}
                    className="w-full rounded-lg border-2 border-dashed border-gray-300"
                    style={{ maxHeight: "400px" }}
                  />
                  <p className="text-sm text-gray-600 mt-3 text-center flex items-center justify-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    Arahkan kamera ke QR code terenkripsi untuk memindai
                  </p>
                </div>
              </div>
            )}

            {message && (
              <div
                className={`p-4 rounded-lg border flex items-center gap-3 ${
                  messageType === "success"
                    ? "bg-green-50 border-green-200 text-green-700"
                    : messageType === "error"
                      ? "bg-red-50 border-red-200 text-red-700"
                      : messageType === "warning"
                        ? "bg-yellow-50 border-yellow-200 text-yellow-700"
                        : "bg-blue-50 border-blue-200 text-blue-700"
                }`}
              >
                {messageType === "success" && <CheckCircle className="w-5 h-5" />}
                {messageType === "error" && <XCircle className="w-5 h-5" />}
                {messageType === "warning" && <AlertCircle className="w-5 h-5" />}
                {messageType === "info" && <AlertCircle className="w-5 h-5" />}
                <p className="font-medium">{message}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Activity */}
        {scanHistory.length > 0 && (
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>{showAllScanned ? "Semua Kode Ter-scan" : "Aktivitas Terbaru"}</CardTitle>
                <div className="flex gap-2">
                  <Badge variant="outline">Total: {scanHistory.length}</Badge>
                  {!showAllScanned && scanHistory.length > 10 && (
                    <Button variant="ghost" size="sm" onClick={toggleShowAllScanned}>
                      Lihat Semua
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className={`space-y-3 ${!showAllScanned ? "max-h-60" : "max-h-96"} overflow-y-auto`}>
                {(showAllScanned ? scanHistory : scanHistory.slice(0, 10)).map((item) => {
                  // Hitung scan count untuk user ini
                  const userScanCount = scanHistory.filter(
                    (h) => h.users?.name.toLowerCase() === item.users?.name.toLowerCase() && h.status === "success",
                  ).length

                  return (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Badge variant={item.status === "success" ? "default" : "secondary"}>
                          {item.barcodes?.code}
                        </Badge>
                        <div className="flex flex-col">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-gray-900">{item.users?.name}</span>
                            {userScanCount >= 10 && (
                              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-xs">
                                <Crown className="w-3 h-3 mr-1" />
                                Gift Eligible
                              </Badge>
                            )}
                          </div>
                          <span className="text-xs text-gray-600">
                            {new Date(item.created_at).toLocaleString("id-ID")}
                          </span>
                          {item.status === "success" && (
                            <span className="text-xs text-blue-600">
                              Scan ke-{userScanCount} untuk {item.users?.name}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex flex-col items-end gap-1">
                          <Badge variant={item.status === "success" ? "default" : "destructive"}>
                            {item.status === "success" ? "Berhasil" : "Duplikat"}
                          </Badge>
                          {item.status === "success" && (
                            <span className="text-xs text-green-600 font-medium">✓ Ter-redeem</span>
                          )}
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setShowDeleteConfirm(item.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          disabled={loading}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
              {showAllScanned && scanHistory.length > 20 && (
                <div className="mt-4 text-center">
                  <Button variant="ghost" size="sm" onClick={() => setShowAllScanned(false)}>
                    Tampilkan Lebih Sedikit
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
