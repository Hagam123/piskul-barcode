"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Database, CheckCircle, XCircle, RefreshCw, AlertCircle, Plus } from "lucide-react"
import Link from "next/link"
import { supabase, checkDatabaseSetup } from "@/lib/supabase"

export default function DatabaseSetupPage() {
  const [isConnected, setIsConnected] = useState<boolean | null>(null)
  const [barcodeCount, setBarcodeCount] = useState<number | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [seedingStatus, setSeedingStatus] = useState<"idle" | "seeding" | "success" | "error">("idle")
  const [seedingMessage, setSeedingMessage] = useState<string>("")

  const checkDatabaseStatus = async () => {
    setLoading(true)
    setError(null)

    try {
      // Test koneksi database dan setup
      const setupResult = await checkDatabaseSetup()

      if (setupResult.error) {
        setError(setupResult.error)
        setIsConnected(false)
      } else {
        setIsConnected(setupResult.tablesExist)
        setBarcodeCount(setupResult.barcodesCount)
      }
    } catch (e) {
      console.error("Error checking database status:", e)
      setError(e instanceof Error ? e.message : "Unknown error occurred")
      setIsConnected(false)
    } finally {
      setLoading(false)
    }
  }

  const seedBarcodes = async () => {
    try {
      setSeedingStatus("seeding")
      setSeedingMessage("Menyiapkan data barcode...")

      // Buat array barcode
      const barcodes = Array.from({ length: 50 }, (_, i) => ({
        code: `PSK${String(i + 1).padStart(3, "0")}-PISKUL-2024`,
        is_redeemed: false,
      }))

      setSeedingMessage("Menambahkan barcode ke database...")

      // Tambahkan barcode ke database
      const { data, error } = await supabase.from("barcodes").upsert(barcodes, { onConflict: "code" }).select()

      if (error) {
        console.error("Error seeding barcodes:", error)
        setSeedingStatus("error")
        setSeedingMessage(`Gagal menambahkan barcode: ${error.message}`)
        return
      }

      console.log("Barcodes seeded successfully:", data)
      setSeedingStatus("success")
      setSeedingMessage(`Berhasil menambahkan ${data.length} barcode ke database!`)

      // Refresh data
      await checkDatabaseStatus()
    } catch (e) {
      console.error("Exception in seedBarcodes:", e)
      setSeedingStatus("error")
      setSeedingMessage(`Terjadi kesalahan: ${e instanceof Error ? e.message : "Unknown error"}`)
    }
  }

  const createTables = async () => {
    try {
      setSeedingStatus("seeding")
      setSeedingMessage("Membuat tabel database...")

      // Buat tabel barcodes
      const { error: barcodesError } = await supabase.rpc("create_tables")

      if (barcodesError) {
        console.error("Error creating tables:", barcodesError)
        setSeedingStatus("error")
        setSeedingMessage(`Gagal membuat tabel: ${barcodesError.message}`)
        return
      }

      setSeedingStatus("success")
      setSeedingMessage("Berhasil membuat tabel database!")

      // Refresh data
      await checkDatabaseStatus()
    } catch (e) {
      console.error("Exception in createTables:", e)
      setSeedingStatus("error")
      setSeedingMessage(`Terjadi kesalahan: ${e instanceof Error ? e.message : "Unknown error"}`)
    }
  }

  useEffect(() => {
    checkDatabaseStatus()
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Kembali ke Scanner
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                  <Database className="w-6 h-6 text-blue-600" />
                  Setup Database
                </h1>
                <p className="text-gray-600">Siapkan dan isi database Supabase</p>
              </div>
            </div>
            <Button onClick={checkDatabaseStatus} disabled={loading} className="flex items-center gap-2">
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
              {loading ? "Memeriksa..." : "Refresh"}
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Connection Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Status Database
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {loading ? (
              <div className="flex items-center justify-center p-6">
                <div className="flex flex-col items-center gap-3">
                  <RefreshCw className="w-8 h-8 text-blue-600 animate-spin" />
                  <p className="text-gray-600">Memeriksa koneksi database...</p>
                </div>
              </div>
            ) : error ? (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <AlertCircle className="w-6 h-6 text-red-600" />
                  <div>
                    <h3 className="font-bold text-red-700">Error Koneksi Database</h3>
                    <p className="text-sm text-red-600">{error}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center ${isConnected ? "bg-green-500" : "bg-red-500"}`}
                    >
                      {isConnected ? (
                        <CheckCircle className="w-6 h-6 text-white" />
                      ) : (
                        <XCircle className="w-6 h-6 text-white" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900">Status Koneksi</h3>
                      <p className="text-sm text-gray-600">
                        {isConnected ? "Terhubung ke database Supabase" : "Tidak dapat terhubung ke database Supabase"}
                      </p>
                    </div>
                  </div>
                  <Badge className={isConnected ? "bg-green-500 text-white" : "bg-red-500 text-white"}>
                    {isConnected ? "Connected" : "Disconnected"}
                  </Badge>
                </div>

                {isConnected && (
                  <div className="space-y-3">
                    <h3 className="font-semibold text-gray-900">Data Statistics</h3>

                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-blue-700">Jumlah Barcode</p>
                          <p className="text-2xl font-bold text-blue-600">
                            {barcodeCount !== null ? barcodeCount : "—"}
                          </p>
                        </div>
                        <div>
                          {barcodeCount === 0 && (
                            <Button onClick={seedBarcodes} className="flex items-center gap-2">
                              <Plus className="w-4 h-4" />
                              Tambah 50 Barcode
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {!isConnected && (
                  <div className="space-y-4">
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                      <div className="flex items-center gap-3">
                        <AlertCircle className="w-6 h-6 text-yellow-600" />
                        <div>
                          <h3 className="font-bold text-yellow-700">Troubleshooting</h3>
                          <ul className="text-sm text-yellow-600 space-y-1 mt-1">
                            <li>• Pastikan environment variables Supabase sudah dikonfigurasi dengan benar</li>
                            <li>• Periksa apakah tabel-tabel database sudah dibuat</li>
                            <li>• Pastikan koneksi internet Anda stabil</li>
                            <li>• Cek apakah service Supabase sedang mengalami gangguan</li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    <Button onClick={createTables} className="w-full flex items-center justify-center gap-2">
                      <Database className="w-4 h-4" />
                      Buat Tabel Database
                    </Button>
                  </div>
                )}

                {seedingStatus !== "idle" && (
                  <div
                    className={`p-4 rounded-lg border ${
                      seedingStatus === "seeding"
                        ? "bg-blue-50 border-blue-200"
                        : seedingStatus === "success"
                          ? "bg-green-50 border-green-200"
                          : "bg-red-50 border-red-200"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {seedingStatus === "seeding" && <RefreshCw className="w-5 h-5 text-blue-600 animate-spin" />}
                      {seedingStatus === "success" && <CheckCircle className="w-5 h-5 text-green-600" />}
                      {seedingStatus === "error" && <XCircle className="w-5 h-5 text-red-600" />}
                      <p
                        className={`text-sm ${
                          seedingStatus === "seeding"
                            ? "text-blue-700"
                            : seedingStatus === "success"
                              ? "text-green-700"
                              : "text-red-700"
                        }`}
                      >
                        {seedingMessage}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Database Schema */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Schema Database
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-2">Tabel barcodes</h3>
                <pre className="text-xs font-mono bg-gray-100 p-3 rounded overflow-x-auto">
                  {`CREATE TABLE barcodes (
  id SERIAL PRIMARY KEY,
  code VARCHAR(255) NOT NULL UNIQUE,
  is_redeemed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  redeemed_at TIMESTAMP WITH TIME ZONE
);`}
                </pre>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-2">Tabel users</h3>
                <pre className="text-xs font-mono bg-gray-100 p-3 rounded overflow-x-auto">
                  {`CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  scan_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);`}
                </pre>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-2">Tabel scans</h3>
                <pre className="text-xs font-mono bg-gray-100 p-3 rounded overflow-x-auto">
                  {`CREATE TABLE scans (
  id SERIAL PRIMARY KEY,
  barcode_id INTEGER REFERENCES barcodes(id),
  user_id INTEGER REFERENCES users(id),
  status VARCHAR(50) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);`}
                </pre>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-2">Tabel gift_eligibility</h3>
                <pre className="text-xs font-mono bg-gray-100 p-3 rounded overflow-x-auto">
                  {`CREATE TABLE gift_eligibility (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  is_claimed BOOLEAN DEFAULT FALSE,
  eligible_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  claimed_date TIMESTAMP WITH TIME ZONE
);`}
                </pre>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SQL untuk membuat tabel */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              SQL untuk Membuat Tabel
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-sm text-gray-600">
                Jika Anda perlu membuat tabel secara manual, gunakan SQL berikut di SQL Editor Supabase:
              </p>
              <pre className="text-xs font-mono bg-gray-100 p-3 rounded overflow-x-auto">
                {`-- Tabel untuk menyimpan data barcode
CREATE TABLE barcodes (
  id SERIAL PRIMARY KEY,
  code VARCHAR(255) NOT NULL UNIQUE,
  is_redeemed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  redeemed_at TIMESTAMP WITH TIME ZONE
);

-- Tabel untuk menyimpan data pengguna
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  scan_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabel untuk menyimpan riwayat scan
CREATE TABLE scans (
  id SERIAL PRIMARY KEY,
  barcode_id INTEGER REFERENCES barcodes(id),
  user_id INTEGER REFERENCES users(id),
  status VARCHAR(50) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabel untuk menyimpan data gift eligibility
CREATE TABLE gift_eligibility (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  is_claimed BOOLEAN DEFAULT FALSE,
  eligible_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  claimed_date TIMESTAMP WITH TIME ZONE
);

-- Stored procedure untuk membuat tabel
CREATE OR REPLACE FUNCTION create_tables()
RETURNS void AS $$
BEGIN
  -- Buat tabel barcodes jika belum ada
  CREATE TABLE IF NOT EXISTS barcodes (
    id SERIAL PRIMARY KEY,
    code VARCHAR(255) NOT NULL UNIQUE,
    is_redeemed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    redeemed_at TIMESTAMP WITH TIME ZONE
  );

  -- Buat tabel users jika belum ada
  CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    scan_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
  );

  -- Buat tabel scans jika belum ada
  CREATE TABLE IF NOT EXISTS scans (
    id SERIAL PRIMARY KEY,
    barcode_id INTEGER REFERENCES barcodes(id),
    user_id INTEGER REFERENCES users(id),
    status VARCHAR(50) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
  );

  -- Buat tabel gift_eligibility jika belum ada
  CREATE TABLE IF NOT EXISTS gift_eligibility (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    is_claimed BOOLEAN DEFAULT FALSE,
    eligible_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    claimed_date TIMESTAMP WITH TIME ZONE
  );
END;
$$ LANGUAGE plpgsql;

-- SQL untuk menambahkan 50 barcode
INSERT INTO barcodes (code) VALUES
('PSK001-PISKUL-2024'),
('PSK002-PISKUL-2024'),
('PSK003-PISKUL-2024'),
('PSK004-PISKUL-2024'),
('PSK005-PISKUL-2024'),
('PSK006-PISKUL-2024'),
('PSK007-PISKUL-2024'),
('PSK008-PISKUL-2024'),
('PSK009-PISKUL-2024'),
('PSK010-PISKUL-2024'),
('PSK011-PISKUL-2024'),
('PSK012-PISKUL-2024'),
('PSK013-PISKUL-2024'),
('PSK014-PISKUL-2024'),
('PSK015-PISKUL-2024'),
('PSK016-PISKUL-2024'),
('PSK017-PISKUL-2024'),
('PSK018-PISKUL-2024'),
('PSK019-PISKUL-2024'),
('PSK020-PISKUL-2024'),
('PSK021-PISKUL-2024'),
('PSK022-PISKUL-2024'),
('PSK023-PISKUL-2024'),
('PSK024-PISKUL-2024'),
('PSK025-PISKUL-2024'),
('PSK026-PISKUL-2024'),
('PSK027-PISKUL-2024'),
('PSK028-PISKUL-2024'),
('PSK029-PISKUL-2024'),
('PSK030-PISKUL-2024'),
('PSK031-PISKUL-2024'),
('PSK032-PISKUL-2024'),
('PSK033-PISKUL-2024'),
('PSK034-PISKUL-2024'),
('PSK035-PISKUL-2024'),
('PSK036-PISKUL-2024'),
('PSK037-PISKUL-2024'),
('PSK038-PISKUL-2024'),
('PSK039-PISKUL-2024'),
('PSK040-PISKUL-2024'),
('PSK041-PISKUL-2024'),
('PSK042-PISKUL-2024'),
('PSK043-PISKUL-2024'),
('PSK044-PISKUL-2024'),
('PSK045-PISKUL-2024'),
('PSK046-PISKUL-2024'),
('PSK047-PISKUL-2024'),
('PSK048-PISKUL-2024'),
('PSK049-PISKUL-2024'),
('PSK050-PISKUL-2024')
ON CONFLICT (code) DO NOTHING;`}
              </pre>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
