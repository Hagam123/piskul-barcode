// Simple encryption utility untuk barcode
const ENCRYPTION_KEY = "PISKUL2024SECRET"

export function encryptBarcode(barcode: string): string {
  try {
    // Tambahkan timestamp dan random salt untuk keamanan
    const timestamp = Date.now().toString()
    const salt = Math.random().toString(36).substring(2, 8)
    const payload = `${barcode}|${timestamp}|${salt}`

    // Simple XOR encryption dengan key
    let encrypted = ""
    for (let i = 0; i < payload.length; i++) {
      const keyChar = ENCRYPTION_KEY.charCodeAt(i % ENCRYPTION_KEY.length)
      const payloadChar = payload.charCodeAt(i)
      encrypted += String.fromCharCode(payloadChar ^ keyChar)
    }

    // Convert to base64 untuk QR code compatibility
    return btoa(encrypted)
  } catch (error) {
    console.error("Encryption error:", error)
    return barcode // Fallback ke barcode asli jika error
  }
}

export function decryptBarcode(encryptedData: string): string | null {
  try {
    // Decode dari base64
    const encrypted = atob(encryptedData)

    // Decrypt dengan XOR
    let decrypted = ""
    for (let i = 0; i < encrypted.length; i++) {
      const keyChar = ENCRYPTION_KEY.charCodeAt(i % ENCRYPTION_KEY.length)
      const encryptedChar = encrypted.charCodeAt(i)
      decrypted += String.fromCharCode(encryptedChar ^ keyChar)
    }

    // Extract barcode dari payload
    const parts = decrypted.split("|")
    if (parts.length >= 3) {
      const barcode = parts[0]
      const timestamp = Number.parseInt(parts[1])

      // Validasi timestamp (maksimal 1 tahun)
      const now = Date.now()
      const oneYear = 365 * 24 * 60 * 60 * 1000
      if (now - timestamp > oneYear) {
        console.warn("Barcode expired")
        return null
      }

      return barcode
    }

    return null
  } catch (error) {
    console.error("Decryption error:", error)
    return null
  }
}

// Validasi format barcode Piskul
export function isValidPiskulBarcode(barcode: string): boolean {
  const pattern = /^PSK\d{3}-PISKUL-2024$/
  return pattern.test(barcode)
}

// Generate secure token untuk QR code
export function generateSecureToken(barcode: string): string {
  const timestamp = Date.now()
  const random = Math.random().toString(36).substring(2, 15)
  const checksum = btoa(`${barcode}${timestamp}${random}`).substring(0, 8)

  return `${encryptBarcode(barcode)}.${checksum}.${timestamp}`
}

// Verify dan extract barcode dari secure token
export function verifySecureToken(token: string): string | null {
  try {
    const parts = token.split(".")
    if (parts.length !== 3) return null

    const [encryptedBarcode, checksum, timestamp] = parts
    const barcode = decryptBarcode(encryptedBarcode)

    if (!barcode || !isValidPiskulBarcode(barcode)) return null

    // Validasi timestamp (maksimal 24 jam)
    const now = Date.now()
    const tokenTime = Number.parseInt(timestamp)
    const maxAge = 24 * 60 * 60 * 1000 // 24 jam

    if (now - tokenTime > maxAge) {
      console.warn("Token expired")
      return null
    }

    return barcode
  } catch (error) {
    console.error("Token verification error:", error)
    return null
  }
}
