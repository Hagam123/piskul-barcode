import { createClient } from "@supabase/supabase-js"

// Gunakan environment variables yang sudah tersedia
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// Pastikan client dibuat dengan benar
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Tambahkan log untuk debugging
console.log("Supabase client initialized with URL:", supabaseUrl ? "URL exists" : "URL missing")

// Database types
export interface Barcode {
  id: number
  code: string
  is_redeemed: boolean
  created_at: string
  redeemed_at?: string
}

export interface User {
  id: number
  name: string
  scan_count: number
  created_at: string
  updated_at: string
}

export interface Scan {
  id: number
  barcode_id: number
  user_id: number
  status: "success" | "duplicate"
  created_at: string
  barcodes?: Barcode
  users?: User
}

export interface GiftEligibility {
  id: number
  user_id: number
  is_claimed: boolean
  eligible_date: string
  claimed_date?: string
  users?: User
}

// Database functions with improved error handling and logging
export async function getBarcodeByCode(code: string): Promise<Barcode | null> {
  try {
    console.log("Fetching barcode with code:", code)
    const { data, error } = await supabase.from("barcodes").select("*").eq("code", code)

    if (error) {
      console.error("Error fetching barcode:", error)
      return null
    }

    // Check if no data found
    if (!data || data.length === 0) {
      console.log("No barcode found with code:", code)
      return null
    }

    // Check if multiple rows found (shouldn't happen with UNIQUE constraint)
    if (data.length > 1) {
      console.warn("Multiple barcodes found with same code:", code)
      return data[0] // Return first one
    }

    console.log("Barcode found:", data[0])
    return data[0]
  } catch (e) {
    console.error("Exception in getBarcodeByCode:", e)
    return null
  }
}

export async function getUserByName(name: string): Promise<User | null> {
  try {
    console.log("Fetching user with name:", name)
    const { data, error } = await supabase.from("users").select("*").eq("name", name)

    if (error) {
      console.error("Error fetching user:", error)
      return null
    }

    // Check if no data found
    if (!data || data.length === 0) {
      console.log("No user found with name:", name)
      return null
    }

    // Return first user if multiple found
    console.log("User found:", data[0])
    return data[0]
  } catch (e) {
    console.error("Exception in getUserByName:", e)
    return null
  }
}

export async function createUser(name: string): Promise<User | null> {
  try {
    console.log("Creating new user with name:", name)
    const { data, error } = await supabase.from("users").insert({ name, scan_count: 0 }).select()

    if (error) {
      console.error("Error creating user:", error)
      return null
    }

    if (!data || data.length === 0) {
      console.error("No data returned after creating user")
      return null
    }

    console.log("User created:", data[0])
    return data[0]
  } catch (e) {
    console.error("Exception in createUser:", e)
    return null
  }
}

export async function updateUserScanCount(userId: number, scanCount: number): Promise<boolean> {
  try {
    console.log("Updating scan count for user ID:", userId, "to", scanCount)
    const { error } = await supabase
      .from("users")
      .update({ scan_count: scanCount, updated_at: new Date().toISOString() })
      .eq("id", userId)

    if (error) {
      console.error("Error updating user scan count:", error)
      return false
    }

    console.log("User scan count updated successfully")
    return true
  } catch (e) {
    console.error("Exception in updateUserScanCount:", e)
    return false
  }
}

export async function markBarcodeAsRedeemed(barcodeId: number): Promise<boolean> {
  try {
    console.log("Marking barcode as redeemed, ID:", barcodeId)
    const { error } = await supabase
      .from("barcodes")
      .update({ is_redeemed: true, redeemed_at: new Date().toISOString() })
      .eq("id", barcodeId)

    if (error) {
      console.error("Error marking barcode as redeemed:", error)
      return false
    }

    console.log("Barcode marked as redeemed successfully")
    return true
  } catch (e) {
    console.error("Exception in markBarcodeAsRedeemed:", e)
    return false
  }
}

export async function createScan(
  barcodeId: number,
  userId: number,
  status: "success" | "duplicate",
): Promise<Scan | null> {
  try {
    console.log("Creating scan record:", { barcodeId, userId, status })
    const { data, error } = await supabase
      .from("scans")
      .insert({ barcode_id: barcodeId, user_id: userId, status })
      .select(`
        *,
        barcodes(*),
        users(*)
      `)

    if (error) {
      console.error("Error creating scan:", error)
      return null
    }

    if (!data || data.length === 0) {
      console.error("No data returned after creating scan")
      return null
    }

    console.log("Scan created successfully:", data[0])
    return data[0]
  } catch (e) {
    console.error("Exception in createScan:", e)
    return null
  }
}

// Perbaiki fungsi deleteScan agar lebih komprehensif
export async function deleteScan(scanId: number): Promise<boolean> {
  try {
    console.log("Deleting scan with ID:", scanId)

    // Pertama, ambil data scan yang akan dihapus
    const { data: scanData, error: fetchError } = await supabase
      .from("scans")
      .select(`
        *,
        barcodes(*),
        users(*)
      `)
      .eq("id", scanId)
      .single()

    if (fetchError || !scanData) {
      console.error("Error fetching scan data:", fetchError)
      return false
    }

    console.log("Scan data to delete:", scanData)

    // Jika scan ini adalah scan yang berhasil, kita perlu:
    // 1. Reset status barcode
    // 2. Update scan count user
    // 3. Cek dan hapus gift eligibility jika perlu
    if (scanData.status === "success" && scanData.barcodes && scanData.users) {
      // Reset status barcode
      const { error: barcodeError } = await supabase
        .from("barcodes")
        .update({ is_redeemed: false, redeemed_at: null })
        .eq("id", scanData.barcode_id)

      if (barcodeError) {
        console.error("Error resetting barcode status:", barcodeError)
        return false
      }

      // Update scan count user (kurangi 1)
      const newScanCount = Math.max(0, scanData.users.scan_count - 1)
      const { error: userError } = await supabase
        .from("users")
        .update({ scan_count: newScanCount, updated_at: new Date().toISOString() })
        .eq("id", scanData.user_id)

      if (userError) {
        console.error("Error updating user scan count:", userError)
        return false
      }

      // Cek apakah user masih eligible untuk gift setelah scan count berkurang
      if (newScanCount < 10) {
        // Hapus gift eligibility jika scan count < 10
        const { error: giftError } = await supabase.from("gift_eligibility").delete().eq("user_id", scanData.user_id)

        if (giftError) {
          console.warn("Warning: Could not remove gift eligibility:", giftError)
          // Tidak return false karena ini bukan error kritis
        }
      }
    }

    // Terakhir, hapus scan record
    const { error: deleteError } = await supabase.from("scans").delete().eq("id", scanId)

    if (deleteError) {
      console.error("Error deleting scan:", deleteError)
      return false
    }

    console.log("Scan deleted successfully with all related updates")
    return true
  } catch (e) {
    console.error("Exception in deleteScan:", e)
    return false
  }
}

export async function getScansHistory(): Promise<Scan[]> {
  try {
    console.log("Fetching scans history")
    const { data, error } = await supabase
      .from("scans")
      .select(`
        *,
        barcodes(*),
        users(*)
      `)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching scans history:", error)
      return []
    }

    console.log(`Retrieved ${data?.length || 0} scan records`)
    return data || []
  } catch (e) {
    console.error("Exception in getScansHistory:", e)
    return []
  }
}

// Tambahkan fungsi untuk menghitung ulang scan count user berdasarkan database
export async function recalculateUserScanCount(userId: number): Promise<boolean> {
  try {
    console.log("Recalculating scan count for user ID:", userId)

    // Hitung jumlah scan berhasil untuk user ini
    const { count, error } = await supabase
      .from("scans")
      .select("id", { count: "exact", head: true })
      .eq("user_id", userId)
      .eq("status", "success")

    if (error) {
      console.error("Error counting user scans:", error)
      return false
    }

    const actualScanCount = count || 0

    // Update scan count user
    const { error: updateError } = await supabase
      .from("users")
      .update({ scan_count: actualScanCount, updated_at: new Date().toISOString() })
      .eq("id", userId)

    if (updateError) {
      console.error("Error updating recalculated scan count:", updateError)
      return false
    }

    console.log(`User ${userId} scan count recalculated to ${actualScanCount}`)
    return true
  } catch (e) {
    console.error("Exception in recalculateUserScanCount:", e)
    return false
  }
}

export async function getGiftEligibleUsers(): Promise<GiftEligibility[]> {
  try {
    console.log("Fetching gift eligible users")
    const { data, error } = await supabase
      .from("gift_eligibility")
      .select(`
        *,
        users(*)
      `)
      .order("eligible_date", { ascending: false })

    if (error) {
      console.error("Error fetching gift eligible users:", error)
      return []
    }

    console.log(`Retrieved ${data?.length || 0} gift eligible users`)
    return data || []
  } catch (e) {
    console.error("Exception in getGiftEligibleUsers:", e)
    return []
  }
}

export async function createGiftEligibility(userId: number): Promise<GiftEligibility | null> {
  try {
    console.log("Creating gift eligibility for user ID:", userId)
    const { data, error } = await supabase
      .from("gift_eligibility")
      .insert({ user_id: userId })
      .select(`
        *,
        users(*)
      `)

    if (error) {
      console.error("Error creating gift eligibility:", error)
      return null
    }

    if (!data || data.length === 0) {
      console.error("No data returned after creating gift eligibility")
      return null
    }

    console.log("Gift eligibility created successfully:", data[0])
    return data[0]
  } catch (e) {
    console.error("Exception in createGiftEligibility:", e)
    return null
  }
}

export async function markGiftAsClaimed(userId: number): Promise<boolean> {
  try {
    console.log("Marking gift as claimed for user ID:", userId)
    const { error } = await supabase
      .from("gift_eligibility")
      .update({ is_claimed: true, claimed_date: new Date().toISOString() })
      .eq("user_id", userId)

    if (error) {
      console.error("Error marking gift as claimed:", error)
      return false
    }

    console.log("Gift marked as claimed successfully")
    return true
  } catch (e) {
    console.error("Exception in markGiftAsClaimed:", e)
    return false
  }
}

export async function markGiftAsUnclaimed(userId: number): Promise<boolean> {
  try {
    console.log("Marking gift as unclaimed for user ID:", userId)
    const { error } = await supabase
      .from("gift_eligibility")
      .update({ is_claimed: false, claimed_date: null })
      .eq("user_id", userId)

    if (error) {
      console.error("Error marking gift as unclaimed:", error)
      return false
    }

    console.log("Gift marked as unclaimed successfully")
    return true
  } catch (e) {
    console.error("Exception in markGiftAsUnclaimed:", e)
    return false
  }
}

// Tambahkan fungsi untuk sinkronisasi data
export async function syncDatabaseData(): Promise<boolean> {
  try {
    console.log("Starting database synchronization...")

    // 1. Recalculate semua user scan counts
    const { data: users, error: usersError } = await supabase.from("users").select("id")

    if (usersError) {
      console.error("Error fetching users for sync:", usersError)
      return false
    }

    for (const user of users || []) {
      await recalculateUserScanCount(user.id)
    }

    // 2. Hapus gift eligibility untuk user yang scan count < 10
    const { data: giftUsers, error: giftError } = await supabase.from("gift_eligibility").select(`
        *,
        users(*)
      `)

    if (giftError) {
      console.error("Error fetching gift eligible users for sync:", giftError)
      return false
    }

    for (const giftUser of giftUsers || []) {
      if (giftUser.users && giftUser.users.scan_count < 10) {
        await supabase.from("gift_eligibility").delete().eq("id", giftUser.id)
        console.log(
          `Removed gift eligibility for user ${giftUser.users.name} (scan count: ${giftUser.users.scan_count})`,
        )
      }
    }

    // 3. Reset barcode status untuk barcode yang tidak ada scan berhasil
    const { data: barcodes, error: barcodesError } = await supabase.from("barcodes").select("*").eq("is_redeemed", true)

    if (barcodesError) {
      console.error("Error fetching redeemed barcodes for sync:", barcodesError)
      return false
    }

    for (const barcode of barcodes || []) {
      // Cek apakah ada scan berhasil untuk barcode ini
      const { count, error: scanCountError } = await supabase
        .from("scans")
        .select("id", { count: "exact", head: true })
        .eq("barcode_id", barcode.id)
        .eq("status", "success")

      if (scanCountError) {
        console.error("Error counting barcode scans:", scanCountError)
        continue
      }

      if ((count || 0) === 0) {
        // Tidak ada scan berhasil, reset barcode
        await supabase.from("barcodes").update({ is_redeemed: false, redeemed_at: null }).eq("id", barcode.id)
        console.log(`Reset barcode ${barcode.code} (no successful scans found)`)
      }
    }

    console.log("Database synchronization completed successfully")
    return true
  } catch (e) {
    console.error("Exception in syncDatabaseData:", e)
    return false
  }
}

// Tambahkan fungsi untuk memeriksa koneksi database
export async function testDatabaseConnection(): Promise<boolean> {
  try {
    console.log("Testing database connection...")
    const { data, error } = await supabase.from("barcodes").select("count").limit(1)

    if (error) {
      console.error("Database connection test failed:", error)
      return false
    }

    console.log("Database connection successful!")
    return true
  } catch (e) {
    console.error("Exception in testDatabaseConnection:", e)
    return false
  }
}

// Fungsi untuk mendapatkan semua barcodes
export async function getAllBarcodes(): Promise<Barcode[]> {
  try {
    console.log("Fetching all barcodes")
    const { data, error } = await supabase.from("barcodes").select("*").order("code", { ascending: true })

    if (error) {
      console.error("Error fetching all barcodes:", error)
      return []
    }

    console.log(`Retrieved ${data?.length || 0} barcodes`)
    return data || []
  } catch (e) {
    console.error("Exception in getAllBarcodes:", e)
    return []
  }
}

// Fungsi untuk memeriksa apakah tabel database sudah ada dan berisi data
export async function checkDatabaseSetup(): Promise<{
  tablesExist: boolean
  barcodesCount: number
  usersCount: number
  scansCount: number
  giftCount: number
  error?: string
}> {
  try {
    console.log("Checking database setup...")

    // Check if tables exist and get counts
    const [barcodesResult, usersResult, scansResult, giftResult] = await Promise.all([
      supabase.from("barcodes").select("id", { count: "exact", head: true }),
      supabase.from("users").select("id", { count: "exact", head: true }),
      supabase.from("scans").select("id", { count: "exact", head: true }),
      supabase.from("gift_eligibility").select("id", { count: "exact", head: true }),
    ])

    // Check for any errors
    if (barcodesResult.error || usersResult.error || scansResult.error || giftResult.error) {
      const errors = [
        barcodesResult.error?.message,
        usersResult.error?.message,
        scansResult.error?.message,
        giftResult.error?.message,
      ].filter(Boolean)

      return {
        tablesExist: false,
        barcodesCount: 0,
        usersCount: 0,
        scansCount: 0,
        giftCount: 0,
        error: `Database errors: ${errors.join(", ")}`,
      }
    }

    const result = {
      tablesExist: true,
      barcodesCount: barcodesResult.count || 0,
      usersCount: usersResult.count || 0,
      scansCount: scansResult.count || 0,
      giftCount: giftResult.count || 0,
    }

    console.log("Database setup check result:", result)
    return result
  } catch (e) {
    console.error("Exception in checkDatabaseSetup:", e)
    return {
      tablesExist: false,
      barcodesCount: 0,
      usersCount: 0,
      scansCount: 0,
      giftCount: 0,
      error: e instanceof Error ? e.message : "Unknown error",
    }
  }
}

// Fungsi untuk menambahkan barcode ke database
export async function addBarcodesToDatabase(): Promise<boolean> {
  try {
    console.log("Adding barcodes to database...")

    // Buat array barcode
    const barcodes = Array.from({ length: 50 }, (_, i) => ({
      code: `PSK${String(i + 1).padStart(3, "0")}-PISKUL-2024`,
      is_redeemed: false,
    }))

    // Tambahkan barcode ke database
    const { data, error } = await supabase.from("barcodes").upsert(barcodes, { onConflict: "code" }).select()

    if (error) {
      console.error("Error adding barcodes:", error)
      return false
    }

    console.log(`Successfully added ${data.length} barcodes to database`)
    return true
  } catch (e) {
    console.error("Exception in addBarcodesToDatabase:", e)
    return false
  }
}

// Fungsi untuk reset semua data database
export async function resetAllData(): Promise<boolean> {
  try {
    console.log("Starting database reset...")

    // Hapus semua data dari tabel dalam urutan yang benar (karena foreign key constraints)
    const deleteOperations = [
      supabase.from("gift_eligibility").delete().neq("id", 0),
      supabase.from("scans").delete().neq("id", 0),
      supabase.from("users").delete().neq("id", 0),
      supabase.from("barcodes").update({ is_redeemed: false, redeemed_at: null }).neq("id", 0),
    ]

    // Jalankan semua operasi delete
    for (const operation of deleteOperations) {
      const { error } = await operation
      if (error) {
        console.error("Error during reset operation:", error)
        return false
      }
    }

    console.log("Database reset completed successfully")
    return true
  } catch (e) {
    console.error("Exception in resetAllData:", e)
    return false
  }
}

// Fungsi untuk hapus semua scan dan reset barcode status
export async function deleteAllScans(): Promise<boolean> {
  try {
    console.log("Deleting all scans...")

    // Hapus semua gift eligibility
    const { error: giftError } = await supabase.from("gift_eligibility").delete().neq("id", 0)
    if (giftError) {
      console.error("Error deleting gift eligibility:", giftError)
      return false
    }

    // Hapus semua scans
    const { error: scansError } = await supabase.from("scans").delete().neq("id", 0)
    if (scansError) {
      console.error("Error deleting scans:", scansError)
      return false
    }

    // Reset semua barcode status
    const { error: barcodeError } = await supabase
      .from("barcodes")
      .update({ is_redeemed: false, redeemed_at: null })
      .neq("id", 0)

    if (barcodeError) {
      console.error("Error resetting barcodes:", barcodeError)
      return false
    }

    // Reset scan count semua users
    const { error: usersError } = await supabase
      .from("users")
      .update({ scan_count: 0, updated_at: new Date().toISOString() })
      .neq("id", 0)

    if (usersError) {
      console.error("Error resetting user scan counts:", usersError)
      return false
    }

    console.log("All scans deleted and data reset successfully")
    return true
  } catch (e) {
    console.error("Exception in deleteAllScans:", e)
    return false
  }
}

// Fungsi untuk hapus user dan semua data terkait
export async function deleteUserAndRelatedData(userId: number): Promise<boolean> {
  try {
    console.log("Deleting user and related data for user ID:", userId)

    // Hapus gift eligibility user
    const { error: giftError } = await supabase.from("gift_eligibility").delete().eq("user_id", userId)
    if (giftError) {
      console.error("Error deleting user gift eligibility:", giftError)
      return false
    }

    // Hapus scans user
    const { error: scansError } = await supabase.from("scans").delete().eq("user_id", userId)
    if (scansError) {
      console.error("Error deleting user scans:", scansError)
      return false
    }

    // Hapus user
    const { error: userError } = await supabase.from("users").delete().eq("id", userId)
    if (userError) {
      console.error("Error deleting user:", userError)
      return false
    }

    console.log("User and related data deleted successfully")
    return true
  } catch (e) {
    console.error("Exception in deleteUserAndRelatedData:", e)
    return false
  }
}

// Fungsi untuk mendapatkan statistik database
export async function getDatabaseStats(): Promise<{
  totalBarcodes: number
  redeemedBarcodes: number
  totalUsers: number
  totalScans: number
  totalGifts: number
  error?: string
}> {
  try {
    console.log("Getting database statistics...")

    const [barcodesResult, redeemedResult, usersResult, scansResult, giftsResult] = await Promise.all([
      supabase.from("barcodes").select("id", { count: "exact", head: true }),
      supabase.from("barcodes").select("id", { count: "exact", head: true }).eq("is_redeemed", true),
      supabase.from("users").select("id", { count: "exact", head: true }),
      supabase.from("scans").select("id", { count: "exact", head: true }),
      supabase.from("gift_eligibility").select("id", { count: "exact", head: true }),
    ])

    // Check for errors
    const errors = [
      barcodesResult.error,
      redeemedResult.error,
      usersResult.error,
      scansResult.error,
      giftsResult.error,
    ].filter(Boolean)

    if (errors.length > 0) {
      return {
        totalBarcodes: 0,
        redeemedBarcodes: 0,
        totalUsers: 0,
        totalScans: 0,
        totalGifts: 0,
        error: `Database errors: ${errors.map((e) => e?.message).join(", ")}`,
      }
    }

    const stats = {
      totalBarcodes: barcodesResult.count || 0,
      redeemedBarcodes: redeemedResult.count || 0,
      totalUsers: usersResult.count || 0,
      totalScans: scansResult.count || 0,
      totalGifts: giftsResult.count || 0,
    }

    console.log("Database statistics:", stats)
    return stats
  } catch (e) {
    console.error("Exception in getDatabaseStats:", e)
    return {
      totalBarcodes: 0,
      redeemedBarcodes: 0,
      totalUsers: 0,
      totalScans: 0,
      totalGifts: 0,
      error: e instanceof Error ? e.message : "Unknown error",
    }
  }
}
