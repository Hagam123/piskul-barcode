"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { ArrowLeft, Home, Database, QrCode, Search, Gift, Plus, LogOut } from "lucide-react"

interface NavigationProps {
  currentPage?: string
  giftCount?: number
  onLogout?: () => void
}

export function Navigation({ currentPage = "dashboard", giftCount = 0, onLogout }: NavigationProps) {
  const isActive = (page: string) => currentPage === page

  return (
    <div className="bg-white shadow-sm border-b">
      <div className="max-w-4xl mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            {currentPage !== "dashboard" && (
              <Link href="/">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Dashboard
                </Button>
              </Link>
            )}
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <Database className="w-6 h-6 text-green-600" />
                Redeem Kemasan Piskul
              </h1>
              <p className="text-gray-600 flex items-center gap-2">
                <Database className="w-4 h-4 text-blue-600" />
                {currentPage === "dashboard" ? "Dashboard Admin" : `${currentPage} - Admin Panel`} | Sesi Aktif
              </p>
            </div>
          </div>

          <div className="flex gap-2">
            <Link href="/">
              <Button
                variant={isActive("dashboard") ? "default" : "outline"}
                size="sm"
                className="flex items-center gap-2"
              >
                <Home className="w-4 h-4" />
                Dashboard
              </Button>
            </Link>

            <Link href="/barcodes">
              <Button
                variant={isActive("barcodes") ? "default" : "outline"}
                size="sm"
                className="flex items-center gap-2"
              >
                <QrCode className="w-4 h-4" />
                QR Codes
              </Button>
            </Link>

            <Link href="/scanned">
              <Button
                variant={isActive("scanned") ? "default" : "outline"}
                size="sm"
                className="flex items-center gap-2"
              >
                <Search className="w-4 h-4" />
                Riwayat
              </Button>
            </Link>

            <Link href="/gifts">
              <Button
                variant={isActive("gifts") ? "default" : "outline"}
                size="sm"
                className="flex items-center gap-2 relative"
              >
                <Gift className="w-4 h-4" />
                Gifts
                {giftCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-1 min-w-[20px] h-5">
                    {giftCount}
                  </Badge>
                )}
              </Button>
            </Link>

            <Link href="/database-status">
              <Button
                variant={isActive("database-status") ? "default" : "outline"}
                size="sm"
                className="flex items-center gap-2"
              >
                <Database className="w-4 h-4" />
                Status
              </Button>
            </Link>

            <Link href="/database-setup">
              <Button
                variant={isActive("database-setup") ? "default" : "outline"}
                size="sm"
                className="flex items-center gap-2 text-green-600 border-green-200 hover:bg-green-50"
              >
                <Plus className="w-4 h-4" />
                Setup
              </Button>
            </Link>

            {onLogout && (
              <Button
                variant="outline"
                size="sm"
                onClick={onLogout}
                className="flex items-center gap-2 text-red-600 border-red-200 hover:bg-red-50"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
